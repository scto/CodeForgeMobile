/*
 *    sora-editor - the awesome code editor for Android
 *    https://github.com/Rosemoe/sora-editor
 *    Copyright (C) 2020-2026  Rosemoe
 *
 *     This library is free software; you can redistribute it and/or
 *     modify it under the terms of the GNU Lesser General Public
 *     License as published by the Free Software Foundation; either
 *     version 2.1 of the License, or (at your option) any later version.
 *
 *     This library is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *     Lesser General Public License for more details.
 *
 *     You should have received a copy of the GNU Lesser General Public
 *     License along with this library; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
 *     USA
 *
 *     Please contact Rosemoe by email 2073412493@qq.com if you need
 *     additional information or have any questions
 */
package io.github.rosemoe.sora.text.emoji;

/**
 * Unicode Character Data related to emoji from Unicode 17.0.0
 */
class UnicodeEmojiData {

    private final static int[] PropertyEmoji = {151,
            0x0023, 0x0023,
            0x002a, 0x002a,
            0x0030, 0x0039,
            0x00a9, 0x00a9,
            0x00ae, 0x00ae,
            0x203c, 0x203c,
            0x2049, 0x2049,
            0x2122, 0x2122,
            0x2139, 0x2139,
            0x2194, 0x2199,
            0x21a9, 0x21aa,
            0x231a, 0x231b,
            0x2328, 0x2328,
            0x23cf, 0x23cf,
            0x23e9, 0x23f3,
            0x23f8, 0x23fa,
            0x24c2, 0x24c2,
            0x25aa, 0x25ab,
            0x25b6, 0x25b6,
            0x25c0, 0x25c0,
            0x25fb, 0x25fe,
            0x2600, 0x2604,
            0x260e, 0x260e,
            0x2611, 0x2611,
            0x2614, 0x2615,
            0x2618, 0x2618,
            0x261d, 0x261d,
            0x2620, 0x2620,
            0x2622, 0x2623,
            0x2626, 0x2626,
            0x262a, 0x262a,
            0x262e, 0x262f,
            0x2638, 0x263a,
            0x2640, 0x2640,
            0x2642, 0x2642,
            0x2648, 0x2653,
            0x265f, 0x2660,
            0x2663, 0x2663,
            0x2665, 0x2666,
            0x2668, 0x2668,
            0x267b, 0x267b,
            0x267e, 0x267f,
            0x2692, 0x2697,
            0x2699, 0x2699,
            0x269b, 0x269c,
            0x26a0, 0x26a1,
            0x26a7, 0x26a7,
            0x26aa, 0x26ab,
            0x26b0, 0x26b1,
            0x26bd, 0x26be,
            0x26c4, 0x26c5,
            0x26c8, 0x26c8,
            0x26ce, 0x26cf,
            0x26d1, 0x26d1,
            0x26d3, 0x26d4,
            0x26e9, 0x26ea,
            0x26f0, 0x26f5,
            0x26f7, 0x26fa,
            0x26fd, 0x26fd,
            0x2702, 0x2702,
            0x2705, 0x2705,
            0x2708, 0x270d,
            0x270f, 0x270f,
            0x2712, 0x2712,
            0x2714, 0x2714,
            0x2716, 0x2716,
            0x271d, 0x271d,
            0x2721, 0x2721,
            0x2728, 0x2728,
            0x2733, 0x2734,
            0x2744, 0x2744,
            0x2747, 0x2747,
            0x274c, 0x274c,
            0x274e, 0x274e,
            0x2753, 0x2755,
            0x2757, 0x2757,
            0x2763, 0x2764,
            0x2795, 0x2797,
            0x27a1, 0x27a1,
            0x27b0, 0x27b0,
            0x27bf, 0x27bf,
            0x2934, 0x2935,
            0x2b05, 0x2b07,
            0x2b1b, 0x2b1c,
            0x2b50, 0x2b50,
            0x2b55, 0x2b55,
            0x3030, 0x3030,
            0x303d, 0x303d,
            0x3297, 0x3297,
            0x3299, 0x3299,
            0x1f004, 0x1f004,
            0x1f0cf, 0x1f0cf,
            0x1f170, 0x1f171,
            0x1f17e, 0x1f17f,
            0x1f18e, 0x1f18e,
            0x1f191, 0x1f19a,
            0x1f1e6, 0x1f1ff,
            0x1f201, 0x1f202,
            0x1f21a, 0x1f21a,
            0x1f22f, 0x1f22f,
            0x1f232, 0x1f23a,
            0x1f250, 0x1f251,
            0x1f300, 0x1f321,
            0x1f324, 0x1f393,
            0x1f396, 0x1f397,
            0x1f399, 0x1f39b,
            0x1f39e, 0x1f3f0,
            0x1f3f3, 0x1f3f5,
            0x1f3f7, 0x1f4fd,
            0x1f4ff, 0x1f53d,
            0x1f549, 0x1f54e,
            0x1f550, 0x1f567,
            0x1f56f, 0x1f570,
            0x1f573, 0x1f57a,
            0x1f587, 0x1f587,
            0x1f58a, 0x1f58d,
            0x1f590, 0x1f590,
            0x1f595, 0x1f596,
            0x1f5a4, 0x1f5a5,
            0x1f5a8, 0x1f5a8,
            0x1f5b1, 0x1f5b2,
            0x1f5bc, 0x1f5bc,
            0x1f5c2, 0x1f5c4,
            0x1f5d1, 0x1f5d3,
            0x1f5dc, 0x1f5de,
            0x1f5e1, 0x1f5e1,
            0x1f5e3, 0x1f5e3,
            0x1f5e8, 0x1f5e8,
            0x1f5ef, 0x1f5ef,
            0x1f5f3, 0x1f5f3,
            0x1f5fa, 0x1f64f,
            0x1f680, 0x1f6c5,
            0x1f6cb, 0x1f6d2,
            0x1f6d5, 0x1f6d8,
            0x1f6dc, 0x1f6e5,
            0x1f6e9, 0x1f6e9,
            0x1f6eb, 0x1f6ec,
            0x1f6f0, 0x1f6f0,
            0x1f6f3, 0x1f6fc,
            0x1f7e0, 0x1f7eb,
            0x1f7f0, 0x1f7f0,
            0x1f90c, 0x1f93a,
            0x1f93c, 0x1f945,
            0x1f947, 0x1f9ff,
            0x1fa70, 0x1fa7c,
            0x1fa80, 0x1fa8a,
            0x1fa8e, 0x1fac6,
            0x1fac8, 0x1fac8,
            0x1facd, 0x1fadc,
            0x1fadf, 0x1faea,
            0x1faef, 0x1faf8,
    };

    private final static int[] PropertyEmojiModifier = {1,
            0x1f3fb, 0x1f3ff,
    };

    private final static int[] PropertyEmojiModifierBase = {40,
            0x261d, 0x261d,
            0x26f9, 0x26f9,
            0x270a, 0x270d,
            0x1f385, 0x1f385,
            0x1f3c2, 0x1f3c4,
            0x1f3c7, 0x1f3c7,
            0x1f3ca, 0x1f3cc,
            0x1f442, 0x1f443,
            0x1f446, 0x1f450,
            0x1f466, 0x1f478,
            0x1f47c, 0x1f47c,
            0x1f481, 0x1f483,
            0x1f485, 0x1f487,
            0x1f48f, 0x1f48f,
            0x1f491, 0x1f491,
            0x1f4aa, 0x1f4aa,
            0x1f574, 0x1f575,
            0x1f57a, 0x1f57a,
            0x1f590, 0x1f590,
            0x1f595, 0x1f596,
            0x1f645, 0x1f647,
            0x1f64b, 0x1f64f,
            0x1f6a3, 0x1f6a3,
            0x1f6b4, 0x1f6b6,
            0x1f6c0, 0x1f6c0,
            0x1f6cc, 0x1f6cc,
            0x1f90c, 0x1f90c,
            0x1f90f, 0x1f90f,
            0x1f918, 0x1f91f,
            0x1f926, 0x1f926,
            0x1f930, 0x1f939,
            0x1f93c, 0x1f93e,
            0x1f977, 0x1f977,
            0x1f9b5, 0x1f9b6,
            0x1f9b8, 0x1f9b9,
            0x1f9bb, 0x1f9bb,
            0x1f9cd, 0x1f9cf,
            0x1f9d1, 0x1f9dd,
            0x1fac3, 0x1fac5,
            0x1faf0, 0x1faf8,
    };

    private final static int[] PropertyVariationSelector = {4,
            0x180b, 0x180d,
            0x180f, 0x180f,
            0xfe00, 0xfe0f,
            0xe0100, 0xe01ef,
    };


    private static boolean isInCodeRange(int[] ranges, int codePoint) {
        int n = ranges[0];
        if (n == 0) return false;
        if (ranges[1] > codePoint || ranges[ranges.length - 1] < codePoint) return false;

        int low = 0;
        int high = n;

        while (low < high) {
            int x = (low + high) >> 1;
            if (codePoint > ranges[1 + x * 2 + 1]) {
                low = x + 1;
            } else {
                high = x;
            }
        }

        return (low < n && codePoint >= ranges[1 + low * 2]);
    }

    public static boolean isEmoji(int codePoint) {
        return isInCodeRange(PropertyEmoji, codePoint);
    }

    public static boolean isEmojiModifier(int codePoint) {
        return isInCodeRange(PropertyEmojiModifier, codePoint);
    }

    public static boolean isEmojiModifierBase(int codePoint) {
        return isInCodeRange(PropertyEmojiModifierBase, codePoint);
    }

    public static boolean isVariationSelector(int codePoint) {
        return isInCodeRange(PropertyVariationSelector, codePoint);
    }

}
